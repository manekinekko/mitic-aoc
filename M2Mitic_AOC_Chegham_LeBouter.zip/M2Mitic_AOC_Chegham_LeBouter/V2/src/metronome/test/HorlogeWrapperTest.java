package metronome.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class HorlogeWrapperTest {

	@Test
	public void testHorlogeWrapper() {
		fail("Not yet implemented");
	}

	@Test
	public void testActiverPeriodiquement() {
		fail("Not yet implemented");
	}

	@Test
	public void testActiverApresDelai() {
		fail("Not yet implemented");
	}

	@Test
	public void testDesactiver() {
		fail("Not yet implemented");
	}

}
